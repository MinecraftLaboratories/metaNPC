package com.nikita23830.animearts.common;

import com.nikita23830.animearts.client.DownloadThread;
import com.nikita23830.animearts.common.block.AnimatedArts;
import com.nikita23830.animearts.common.block.DefaultArts;
import net.minecraft.block.Block;

import java.util.ArrayList;

public class RegisterAnimeArts {
    public static RegisterAnimeArts instance;
    public ArrayList<AnimeArt> arts = new ArrayList<AnimeArt>();

    public RegisterAnimeArts() {
        instance = this;
        registerArt("https://raw.githubusercontent.com/nikita23830/test/main/1.png", "testDefault", AnimeType.DEFAULT);
        registerArt("https://c.tenor.com/Pn-mn-nqqrcAAAAC/anime-cute.gif", "testAnimated", AnimeType.ANIMATED);
        registerArt("https://c.tenor.com/ImzK5FFT4VYAAAAC/rem-anime.gif", "testAn", AnimeType.ANIMATED);
    }

    private void registerArt(String url, String name, AnimeType type) {
        AnimeArt art = new AnimeArt(url, name, type);
        arts.add(art);
        art.setId(arts.size() - 1);
    }

    public static class AnimeArt {
        public final String url;
        public final String name;
        public final AnimeType type;
        public int id;
        public Block block;
        public DownloadThread thread;

        public AnimeArt(String url, String name, AnimeType type) {
            this.name = name;
            this.url = url;
            this.type = type;
        }

        public void startDownload() {
            thread = new DownloadThread(url, type == AnimeType.ANIMATED);
        }

        public void setId(int id) {
            this.id = id;
            block = type == AnimeType.DEFAULT ? new DefaultArts(id, name) : new AnimatedArts(id, name);
        }
    }

    public static enum AnimeType {
        DEFAULT,
        ANIMATED
    }
}
