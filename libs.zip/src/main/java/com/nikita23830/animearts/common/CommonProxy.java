package com.nikita23830.animearts.common;

import com.nikita23830.animearts.common.network.NetworkHandler;
import com.nikita23830.animearts.common.tiles.AnimatedArtsTile;
import com.nikita23830.animearts.common.tiles.DefaultAnimeTile;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;

public class CommonProxy {
    public static RegisterAnimeArts register;

    public void init(FMLInitializationEvent event) {
        register = new RegisterAnimeArts();
        GameRegistry.registerTileEntity(DefaultAnimeTile.class, "animeArt:default");
        GameRegistry.registerTileEntity(AnimatedArtsTile.class, "animeArt:animate");
        NetworkHandler.init();
    }
}
