package com.nikita23830.animearts.common.tiles;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.tileentity.TileEntity;

public class DefaultAnimeTile extends TileEntity {

    @SideOnly(Side.CLIENT)
    public double getMaxRenderDistanceSquared() {
        return 50096.0D;
    }

    @Override
    public boolean canUpdate() {
        return false;
    }
}
