package com.nikita23830.animearts.common;

public interface IAnimeArts {
    int getIDArts();
}
