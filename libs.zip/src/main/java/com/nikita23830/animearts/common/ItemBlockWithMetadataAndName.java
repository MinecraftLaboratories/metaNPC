package com.nikita23830.animearts.common;

import com.nikita23830.animearts.common.block.DefaultArts;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBlockWithMetadata;
import net.minecraft.item.ItemStack;
import net.minecraft.util.StatCollector;

import java.util.List;

public class ItemBlockWithMetadataAndName extends ItemBlockWithMetadata {

    public ItemBlockWithMetadataAndName(Block par2Block) {
        super(par2Block, par2Block);
    }

    @Override
    public String getUnlocalizedName(ItemStack par1ItemStack) {
        Block b = Block.getBlockFromItem(par1ItemStack.getItem());
        IAnimeArts art = ((IAnimeArts) b);
        return "animeArt." + (b instanceof DefaultArts ? "default." : "animated.") + CommonProxy.register.arts.get(art.getIDArts()).name;
    }
}
