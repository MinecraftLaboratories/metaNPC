package com.nikita23830.animearts.common.block;

import com.nikita23830.animearts.common.IAnimeArts;
import com.nikita23830.animearts.common.ItemBlockWithMetadataAndName;
import com.nikita23830.animearts.common.RegisterAnimeArts;
import com.nikita23830.animearts.common.network.NetworkHandler;
import com.nikita23830.animearts.common.network.PacketRequestView;
import com.nikita23830.animearts.common.tiles.AnimatedArtsTile;
import com.nikita23830.animearts.common.tiles.DefaultAnimeTile;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

import java.util.ArrayList;

public class AnimatedArts extends Block implements ITileEntityProvider, IAnimeArts {

    private int id;
    private String name;

    public AnimatedArts(int id, String name) {
        super(Material.iron);
        this.setResistance(10.0F);
        this.setHardness(10.0F);
        this.setBlockBounds(0, 0, 0, 1, 1, 1);
        setBlockName("anime_" + id);
        this.id = id;
        this.name = name;
        GameRegistry.registerBlock(this, ItemBlockWithMetadataAndName.class, "anime" + id);
    }

    public AxisAlignedBB getCollisionBoundingBoxFromPool(World w, int x, int y, int z) {
        return null;
    }

    public TileEntity createNewTileEntity(World world, int i) {
        return new AnimatedArtsTile();
    }

    @Override
    public String getLocalizedName() {
        return RegisterAnimeArts.instance.arts.get(getIDArts()).name;
    }

    public int getRenderType() {
        return -1;
    }

    public boolean isOpaqueCube() {
        return false;
    }

    public boolean renderAsNormalBlock() {
        return false;
    }

    @Override
    public void onBlockPlacedBy(World w, int x, int y, int z, EntityLivingBase elb, ItemStack stack) {
        super.onBlockPlacedBy(w, x, y, z, elb, stack);
        TileEntity te = w.getTileEntity(x, y, z);
        if (te instanceof AnimatedArtsTile && elb instanceof EntityPlayer && !w.isRemote)
            NetworkHandler.sendTo(new PacketRequestView(x, y, z), (EntityPlayerMP) elb);
    }

    @SideOnly(Side.CLIENT)
    public boolean onBlockActivated(World w, int x, int y, int z, EntityPlayer p, int i, float f0, float f1, float f2) {
        return true;
    }

    @Override
    public ItemStack getPickBlock(MovingObjectPosition target, World world, int x, int y, int z, EntityPlayer player) {
        return new ItemStack(this, 1, world.getBlockMetadata(x, y, z));
    }

    @Override
    public ItemStack getPickBlock(MovingObjectPosition target, World world, int x, int y, int z) {
        return new ItemStack(this, 1, world.getBlockMetadata(x, y, z));
    }

    @Override
    public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int metadata, int fortune) {
        ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        ret.add(new ItemStack(this, 1, metadata));
        return ret;
    }

    @Override
    public int getIDArts() {
        return id;
    }
}