package com.nikita23830.animearts.common.block;

import com.nikita23830.animearts.common.IAnimeArts;
import com.nikita23830.animearts.common.ItemBlockWithMetadataAndName;
import com.nikita23830.animearts.common.tiles.DefaultAnimeTile;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class DefaultArts extends Block implements ITileEntityProvider, IAnimeArts {

    private int id;
    public String name;

    public DefaultArts(int id, String name) {
        super(Material.iron);
        this.setResistance(10.0F);
        this.setHardness(10.0F);
        this.setBlockBounds(0, 0, 0, 1, 1, 1);
        setBlockName("anime_" + id);
        this.id = id;
        this.name = name;
        GameRegistry.registerBlock(this, ItemBlockWithMetadataAndName.class, "anime" + id);
    }

    @Override
    public String getLocalizedName() {
        return StatCollector.translateToLocal("animeArt.default." + name);
    }

    public AxisAlignedBB getCollisionBoundingBoxFromPool(World w, int x, int y, int z) {
        return null;
    }

    public TileEntity createNewTileEntity(World world, int i) {
        return new DefaultAnimeTile();
    }

    public int getRenderType() {
        return -1;
    }

    public boolean isOpaqueCube() {
        return false;
    }

    public boolean renderAsNormalBlock() {
        return false;
    }

    @SideOnly(Side.CLIENT)
    public boolean onBlockActivated(World w, int x, int y, int z, EntityPlayer p, int i, float f0, float f1, float f2) {
        return true;
    }

    @Override
    public ItemStack getPickBlock(MovingObjectPosition target, World world, int x, int y, int z, EntityPlayer player) {
        return new ItemStack(this, 1, world.getBlockMetadata(x, y, z));
    }

    @Override
    public ItemStack getPickBlock(MovingObjectPosition target, World world, int x, int y, int z) {
        return new ItemStack(this, 1, world.getBlockMetadata(x, y, z));
    }

    @Override
    public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int metadata, int fortune) {
        ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        ret.add(new ItemStack(this, 1, metadata));
        return ret;
    }

    @Override
    public int getIDArts() {
        return id;
    }
}
