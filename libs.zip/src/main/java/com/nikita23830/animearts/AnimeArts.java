package com.nikita23830.animearts;

import com.nikita23830.animearts.common.CommonProxy;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;

@Mod(modid = AnimeArts.MODID, version = AnimeArts.VERSION)
public class AnimeArts {
    public static final String MODID = "animearts";
    public static final String VERSION = "1.0";
    @Mod.Instance
    public static AnimeArts instance;
    @SidedProxy(
            serverSide = "com.nikita23830.animearts.common.CommonProxy",
            clientSide = "com.nikita23830.animearts.client.ClientProxy"
    )
    public static CommonProxy proxy;
    
    @EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init(event);
    }
}
