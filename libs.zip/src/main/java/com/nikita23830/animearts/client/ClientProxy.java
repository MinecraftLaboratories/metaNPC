package com.nikita23830.animearts.client;

import com.nikita23830.animearts.client.render.tiles.AnimatedRender;
import com.nikita23830.animearts.client.render.tiles.AnimeRenderDefault;
import com.nikita23830.animearts.common.CommonProxy;
import com.nikita23830.animearts.common.RegisterAnimeArts;
import com.nikita23830.animearts.common.tiles.AnimatedArtsTile;
import com.nikita23830.animearts.common.tiles.DefaultAnimeTile;
import cpw.mods.fml.client.registry.ClientRegistry;
import cpw.mods.fml.common.event.FMLInitializationEvent;

public class ClientProxy extends CommonProxy {

    public void init(FMLInitializationEvent event) {
        super.init(event);
        for (RegisterAnimeArts.AnimeArt art : CommonProxy.register.arts) {
            art.startDownload();
        }
        ClientRegistry.bindTileEntitySpecialRenderer(DefaultAnimeTile.class, new AnimeRenderDefault());
        ClientRegistry.bindTileEntitySpecialRenderer(AnimatedArtsTile.class, new AnimatedRender());
    }
}
