package com.nikita23830.animearts.client;

import net.minecraft.client.renderer.texture.DynamicTexture;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.net.URL;

public class DownloadThread extends Thread {
    private String url;
    private boolean animated;
    public BufferedImage image;
    public DynamicTexture texture;
    public boolean finalize = false;
    public GifDecoder decoder;

    public DownloadThread(String url, boolean animated) {
        this.url = url;
        this.animated = animated;
        this.start();
    }

    public DynamicTexture getTexture() {
        if (texture == null)
            return texture = new DynamicTexture(this.image);
        return texture;
    }

    @Override
    public void run() {
        super.run();
        if (!this.animated) {
            try {
                this.image = ImageIO.read(new URL(this.url));
                finalize = true;
            } catch (Exception var2) {
                this.image = null;
                var2.printStackTrace();
            }
        } else {
            try {
                decoder = new GifDecoder(this.url);
                decoder.read();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
